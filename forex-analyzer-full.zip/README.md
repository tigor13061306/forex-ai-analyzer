
# Forex Analyzer Starter

Ova aplikacija omogućava korisnicima da uploaduju slike TradingView grafikona i dobiju AI Forex analizu. Prva verzija koristi testni odgovor – kasnije će se povezati sa OpenAI GPT-4o.
